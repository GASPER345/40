
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  source_url text,
  created_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.categories(id) on delete cascade,
  name text,
  image_url text not null,
  source_url text,
  created_at timestamptz not null default now(),
  unique (image_url)
);

create index on public.products(category_id);

alter table public.categories enable row level security;
alter table public.products enable row level security;

create policy "Public read categories" on public.categories for select using (true);
create policy "Public insert categories" on public.categories for insert with check (true);

create policy "Public read products" on public.products for select using (true);
create policy "Public insert products" on public.products for insert with check (true);

alter publication supabase_realtime add table public.categories;
alter publication supabase_realtime add table public.products;
