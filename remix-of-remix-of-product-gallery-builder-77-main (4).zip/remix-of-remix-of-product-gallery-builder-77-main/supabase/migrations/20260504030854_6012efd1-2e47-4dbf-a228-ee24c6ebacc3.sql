
ALTER TABLE public.orders 
  ADD COLUMN IF NOT EXISTS delivery_method text NOT NULL DEFAULT 'dostava',
  ADD COLUMN IF NOT EXISTS pickup_date date;

CREATE TABLE IF NOT EXISTS public.pickup_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  available_dates jsonb NOT NULL DEFAULT '[]'::jsonb,
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.pickup_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "pickup_settings read all" ON public.pickup_settings;
CREATE POLICY "pickup_settings read all" ON public.pickup_settings FOR SELECT USING (true);
DROP POLICY IF EXISTS "pickup_settings insert all" ON public.pickup_settings;
CREATE POLICY "pickup_settings insert all" ON public.pickup_settings FOR INSERT WITH CHECK (true);
DROP POLICY IF EXISTS "pickup_settings update all" ON public.pickup_settings;
CREATE POLICY "pickup_settings update all" ON public.pickup_settings FOR UPDATE USING (true);

INSERT INTO public.pickup_settings (available_dates)
SELECT '[]'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM public.pickup_settings);
