create table if not exists public.import_jobs (
  id uuid primary key default gen_random_uuid(),
  url text not null,
  status text not null default 'queued',
  message text,
  page_type text,
  categories int not null default 0,
  products int not null default 0,
  images int not null default 0,
  errors jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.import_jobs enable row level security;

drop policy if exists "import_jobs read all" on public.import_jobs;
create policy "import_jobs read all" on public.import_jobs for select using (true);

drop policy if exists "import_jobs insert all" on public.import_jobs;
create policy "import_jobs insert all" on public.import_jobs for insert with check (true);

alter publication supabase_realtime add table public.import_jobs;