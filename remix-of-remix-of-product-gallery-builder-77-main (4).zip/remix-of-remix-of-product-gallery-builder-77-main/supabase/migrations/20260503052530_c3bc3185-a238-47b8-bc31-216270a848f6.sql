
-- Orders table
CREATE TABLE public.orders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Ni še plačano',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "orders read all" ON public.orders FOR SELECT USING (true);
CREATE POLICY "orders insert all" ON public.orders FOR INSERT WITH CHECK (true);
CREATE POLICY "orders update all" ON public.orders FOR UPDATE USING (true);
CREATE POLICY "orders delete all" ON public.orders FOR DELETE USING (true);

-- Order items
CREATE TABLE public.order_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id UUID,
  product_name TEXT,
  image_url TEXT,
  quantity INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "order_items read all" ON public.order_items FOR SELECT USING (true);
CREATE POLICY "order_items insert all" ON public.order_items FOR INSERT WITH CHECK (true);
CREATE POLICY "order_items update all" ON public.order_items FOR UPDATE USING (true);
CREATE POLICY "order_items delete all" ON public.order_items FOR DELETE USING (true);

-- Allow public update/delete on products (admin via app password)
CREATE POLICY "Public update products" ON public.products FOR UPDATE USING (true);
CREATE POLICY "Public delete products" ON public.products FOR DELETE USING (true);
