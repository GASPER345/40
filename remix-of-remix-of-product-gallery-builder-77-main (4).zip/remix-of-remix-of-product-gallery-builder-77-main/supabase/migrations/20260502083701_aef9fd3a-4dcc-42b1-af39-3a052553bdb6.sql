ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS description text,
  ADD COLUMN IF NOT EXISTS variants jsonb,
  ADD COLUMN IF NOT EXISTS group_key text,
  ADD COLUMN IF NOT EXISTS product_url text;

ALTER TABLE public.categories
  ADD COLUMN IF NOT EXISTS kind text;

CREATE UNIQUE INDEX IF NOT EXISTS products_image_url_key
  ON public.products (image_url);

CREATE UNIQUE INDEX IF NOT EXISTS categories_source_url_key
  ON public.categories (source_url) WHERE source_url IS NOT NULL;

CREATE INDEX IF NOT EXISTS products_group_key_idx ON public.products (group_key);
CREATE INDEX IF NOT EXISTS products_product_url_idx ON public.products (product_url);

INSERT INTO storage.buckets (id, name, public)
VALUES ('product-images', 'product-images', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "Public read product-images" ON storage.objects;
CREATE POLICY "Public read product-images"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'product-images');

DROP POLICY IF EXISTS "Public write product-images" ON storage.objects;
CREATE POLICY "Public write product-images"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'product-images');

DROP POLICY IF EXISTS "Public update product-images" ON storage.objects;
CREATE POLICY "Public update product-images"
  ON storage.objects FOR UPDATE
  USING (bucket_id = 'product-images');