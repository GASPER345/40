// Analyzes an uploaded LEGO product image using Lovable AI and returns
// a guessed product name and best-fit category from the provided list.
import "https://deno.land/x/xhr@0.1.0/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { imageBase64, imageUrl, categories } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY ni nastavljen");

    const catList: string[] = Array.isArray(categories) && categories.length
      ? categories
      : ["Technic","Star Wars","Harry Potter","Marvel","DC","Ninjago","Disney","Icons","Architecture","Creator","Nogomet","Super Mario","Drugo"];

    const imageContent = imageBase64
      ? { type: "image_url", image_url: { url: `data:image/jpeg;base64,${imageBase64}` } }
      : { type: "image_url", image_url: { url: imageUrl } };

    const body = {
      model: "google/gemini-2.5-flash",
      messages: [
        {
          role: "system",
          content: `Si LEGO strokovnjak. Iz slike LEGO seta v slovenščini razberi najbolj verjetno ime seta in kategorijo. Kategorije so OMEJENE na: ${catList.join(", ")}. Vedno izberi eno od teh. Če nisi prepričan, uporabi "Drugo".`,
        },
        {
          role: "user",
          content: [
            { type: "text", text: "Analiziraj ta LEGO set in vrni ime ter kategorijo." },
            imageContent,
          ],
        },
      ],
      tools: [
        {
          type: "function",
          function: {
            name: "set_product",
            description: "Vrne ime in kategorijo LEGO seta",
            parameters: {
              type: "object",
              properties: {
                name: { type: "string", description: "Ime LEGO seta (kratko, opisno)" },
                category: { type: "string", enum: catList },
              },
              required: ["name", "category"],
              additionalProperties: false,
            },
          },
        },
      ],
      tool_choice: { type: "function", function: { name: "set_product" } },
    };

    const r = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    if (r.status === 429) {
      return new Response(JSON.stringify({ error: "Preveč zahtev. Poskusi kasneje." }), {
        status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (r.status === 402) {
      return new Response(JSON.stringify({ error: "Zmanjkalo kreditov za AI." }), {
        status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!r.ok) {
      const t = await r.text();
      throw new Error(`AI napaka: ${t}`);
    }

    const data = await r.json();
    const call = data.choices?.[0]?.message?.tool_calls?.[0];
    const args = call ? JSON.parse(call.function.arguments) : {};
    const name = args.name || "LEGO Set";
    const category = catList.includes(args.category) ? args.category : "Drugo";

    return new Response(JSON.stringify({ success: true, name, category }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("analyze-product-image error", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Napaka" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
