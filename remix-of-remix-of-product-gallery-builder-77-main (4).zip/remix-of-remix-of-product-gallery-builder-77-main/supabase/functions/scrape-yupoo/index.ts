import { createClient } from "https://esm.sh/@supabase/supabase-js@2.95.0";
import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const FIRECRAWL = "https://api.firecrawl.dev/v2";
const BUCKET = "product-images";

// ---------- helpers ----------
function slugify(s: string) {
  return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 80) || "untitled";
}
function decodeHtml(s: string) {
  return s.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">");
}
function attr(tag: string, name: string): string | null {
  const m = tag.match(new RegExp(`\\b${name}="([^"]*)"`, "i"));
  return m ? m[1] : null;
}
function absUrl(src: string, base: string) {
  if (src.startsWith("//")) return "https:" + src;
  if (src.startsWith("http")) return src;
  try { return new URL(src, base).toString(); } catch { return src; }
}

// Map yupoo album/category name into our fixed taxonomy
function mapKind(name: string): string {
  const n = name.toLowerCase();
  if (/(shoe|sneaker|kick|trainer|boot|footwear|nike|adidas|jordan|yeezy|dunk|af1|af-1|sb|nb|new balance|asics)/i.test(n)) return "sneakers";
  if (/(bag|backpack|tote|handbag|wallet|purse|clutch|duffel|luggage)/i.test(n)) return "bags";
  if (/(watch|rolex|ap|patek|omega|seiko|casio|g-shock)/i.test(n)) return "watches";
  if (/(jersey|shirt|tee|hoodie|jacket|pant|short|trouser|coat|apparel|cloth|tracksuit|sweater|polo)/i.test(n)) return "apparel";
  if (/(hat|cap|belt|sock|sunglass|glasses|scarf|glove|jewel|necklace|ring|bracelet|earring|accessor)/i.test(n)) return "accessories";
  return "misc";
}

async function fc(path: string, body: unknown, key: string, timeoutMs = 45000): Promise<any> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(`${FIRECRAWL}${path}`, {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: ctrl.signal,
    });
    const json = await r.json().catch(() => ({}));
    if (!r.ok) {
      console.error(`firecrawl ${path} ${r.status}`, json);
      return { ok: false, status: r.status, json };
    }
    return { ok: true, json };
  } catch (e) {
    console.error("firecrawl fetch err", e);
    return { ok: false, status: 0, json: { error: String(e) } };
  } finally {
    clearTimeout(t);
  }
}

interface Album { name: string; url: string }
interface Product { name: string; image_url: string; product_url?: string; description?: string; variants?: string[] }

// ---------- HTML parsing ----------
function detectPageType(url: string, html: string): "categories" | "album" | "product" {
  // Yupoo has /categories/<id> (lists albums), /albums/<id> (lists photos), and rare single product pages
  if (/\/categories\//i.test(url)) return "categories";
  if (/\/albums?\//i.test(url)) return "album";
  // Heuristic: if html contains album__main cards => listing, otherwise treat as album
  if (/class="[^"]*album__main/i.test(html)) return "categories";
  return "album";
}

function extractAlbums(html: string, base: string): Album[] {
  const out: Album[] = [];
  const seen = new Set<string>();
  const re = /<a\b[^>]*\bclass="[^"]*album__main[^"]*"[^>]*>/gi;
  let m;
  while ((m = re.exec(html))) {
    const tag = m[0];
    const href = attr(tag, "href");
    const title = attr(tag, "title") || "";
    if (!href) continue;
    const url = absUrl(decodeHtml(href), base);
    if (seen.has(url)) continue;
    seen.add(url);
    out.push({ name: decodeHtml(title).trim() || "Album", url });
  }
  return out;
}

function extractAlbumTitle(html: string): string | null {
  const m = html.match(/<h1[^>]*class="[^"]*showalbumheader__gallerytitle[^"]*"[^>]*>([\s\S]*?)<\/h1>/i)
        || html.match(/<title>([^<]+)<\/title>/i);
  if (!m) return null;
  return decodeHtml(m[1].replace(/<[^>]+>/g, "")).trim();
}

function extractAlbumDescription(html: string): string | null {
  const m = html.match(/<meta\s+name="description"\s+content="([^"]+)"/i);
  return m ? decodeHtml(m[1]).trim() : null;
}

function extractProducts(html: string, base: string): Product[] {
  const out: Product[] = [];
  const seen = new Set<string>();

  const imgRe = /<img\b[^>]*>/gi;
  let im;
  while ((im = imgRe.exec(html))) {
    const tag = im[0];
    let src = attr(tag, "data-origin-src") || attr(tag, "data-src") || attr(tag, "data-original") || attr(tag, "src");
    if (!src) continue;
    src = absUrl(src, base);
    if (!/photo\.yupoo\.com/i.test(src)) continue;
    if (/avatar|logo|icon|loading_icon|data:image/i.test(src)) continue;
    // Force highest resolution variant if Yupoo offers _small/_medium suffixes
    src = src.replace(/_(small|medium)\./i, "_origin.");
    if (seen.has(src)) continue;
    seen.add(src);
    const name = attr(tag, "alt") || attr(tag, "title") || "";
    out.push({ name: decodeHtml(name).trim(), image_url: src });
  }
  return out;
}

// ---------- Image download ----------
const BROWSER_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

async function downloadAndUpload(
  supabase: any,
  imageUrl: string,
  pathPrefix: string,
  referer: string,
): Promise<string | null> {
  // Try a few resolution variants in order — Yupoo blocks some, allows others
  const variants = Array.from(new Set([
    imageUrl,
    imageUrl.replace(/\/(square|small|medium|big)\./i, "/origin."),
    imageUrl.replace(/\/origin\./i, "/medium."),
    imageUrl.replace(/\/origin\./i, "/big."),
  ]));
  for (const candidate of variants) {
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 15000);
      const r = await fetch(candidate, {
        headers: {
          "Referer": referer,
          "User-Agent": BROWSER_UA,
          "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
          "Accept-Language": "en-US,en;q=0.9",
        },
        signal: ctrl.signal,
      });
      clearTimeout(t);
      if (!r.ok) { console.warn("img fetch fail", r.status, candidate); continue; }
      const buf = new Uint8Array(await r.arrayBuffer());
      if (buf.byteLength < 500) continue;
      const ext = (candidate.match(/\.(jpe?g|png|webp|gif)/i)?.[1] || "jpg").toLowerCase();
      const hash = await crypto.subtle.digest("SHA-1", new TextEncoder().encode(candidate));
      const hex = Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, "0")).join("").slice(0, 16);
      const path = `${pathPrefix}/${hex}.${ext}`;
      const ct = r.headers.get("content-type") || `image/${ext === "jpg" ? "jpeg" : ext}`;
      const { error } = await supabase.storage.from(BUCKET).upload(path, buf, {
        contentType: ct,
        upsert: true,
      });
      if (error) { console.warn("storage upload err", error.message); return null; }
      const { data } = supabase.storage.from(BUCKET).getPublicUrl(path);
      return data.publicUrl;
    } catch (e) {
      console.warn("downloadAndUpload err", e);
    }
  }
  return null;
}

// ---------- background worker ----------
async function runImport(jobId: string, url: string, FIRECRAWL_API_KEY: string) {
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  const errors: string[] = [];
  const categoriesAdded: string[] = [];
  let totalProducts = 0;
  let totalImages = 0;

  const update = async (patch: Record<string, unknown>) => {
    await supabase.from("import_jobs").update({ ...patch, updated_at: new Date().toISOString() }).eq("id", jobId);
  };

  try {
    await update({ status: "running", message: "Loading Yupoo page…" });

    const entry = await fc("/scrape", {
      url, formats: ["html"], onlyMainContent: false, waitFor: 2500,
    }, FIRECRAWL_API_KEY);

    if (!entry.ok) {
      await update({
        status: "failed",
        message: `Could not load page (Firecrawl ${entry.status}). Check the link or try again later.`,
      });
      return;
    }

    const entryHtml: string = entry.json?.data?.html ?? entry.json?.html ?? "";
    const pageType = detectPageType(url, entryHtml);

    let albums: Album[] = [];
    if (pageType === "categories") {
      albums = extractAlbums(entryHtml, url).slice(0, 40);
    } else {
      const title = extractAlbumTitle(entryHtml) || "Imported";
      albums = [{ name: title, url }];
    }
    if (albums.length === 0) {
      albums = [{ name: extractAlbumTitle(entryHtml) || "Imported", url }];
    }

    await update({ page_type: pageType, message: `Found ${albums.length} album(s). Scanning…` });

    let albumIdx = 0;
    for (const album of albums) {
      albumIdx++;
      try {
        const slug = slugify(album.name);
        const kind = mapKind(album.name);
        const { data: cat, error: catErr } = await supabase
          .from("categories")
          .upsert({ name: album.name, slug, source_url: album.url, kind }, { onConflict: "slug" })
          .select()
          .single();
        if (catErr || !cat) {
          errors.push(`Category "${album.name}": ${catErr?.message || "unknown"}`);
          continue;
        }
        if (!categoriesAdded.includes(cat.name)) categoriesAdded.push(cat.name);

        await update({
          message: `(${albumIdx}/${albums.length}) ${album.name}`,
          categories: categoriesAdded.length,
        });

        let html = entryHtml;
        if (pageType === "categories" || album.url !== url) {
          const page = await fc("/scrape", {
            url: album.url, formats: ["html"], onlyMainContent: false, waitFor: 2000,
          }, FIRECRAWL_API_KEY);
          if (!page.ok) {
            errors.push(`Album "${album.name}": Firecrawl ${page.status}`);
            continue;
          }
          html = page.json?.data?.html ?? page.json?.html ?? "";
        }

        const description = extractAlbumDescription(html);
        const products = extractProducts(html, album.url).slice(0, 120);
        if (products.length === 0) continue;

        for (const p of products) {
          try {
            const stored = await downloadAndUpload(supabase, p.image_url, `${kind}/${slug}`, album.url);
            // Fallback: if Yupoo blocked the image fetch, store the hotlink URL so
            // the user still sees something instead of an empty import.
            const finalUrl = stored || p.image_url;
            const row = {
              category_id: cat.id,
              name: p.name || album.name,
              image_url: finalUrl,
              source_url: album.url,
              product_url: p.product_url || null,
              description,
              group_key: slug,
            };
            const { error: insErr } = await supabase
              .from("products")
              .upsert(row, { onConflict: "image_url" });
            if (insErr) { console.warn("insert err", insErr.message); continue; }
            totalImages++;
            if (totalImages % 5 === 0) {
              await update({ images: totalImages, products: totalProducts + products.length });
            }
          } catch (e) {
            console.warn("product err", e);
          }
        }
        totalProducts += products.length;
        await update({ images: totalImages, products: totalProducts });
      } catch (e) {
        console.error("album loop err", e);
        errors.push(album.name + ": " + (e instanceof Error ? e.message : String(e)));
      }
    }

    await update({
      status: "completed",
      message: `Done. ${categoriesAdded.length} categories, ${totalImages} images.`,
      categories: categoriesAdded.length,
      products: totalProducts,
      images: totalImages,
      errors: errors.slice(0, 20),
    });
  } catch (e) {
    console.error("fatal", e);
    await update({
      status: "failed",
      message: e instanceof Error ? e.message : "Unknown error",
      errors: errors.slice(0, 20),
    });
  }
}

// ---------- HTTP handler ----------
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const reply = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  try {
    const FIRECRAWL_API_KEY = Deno.env.get("FIRECRAWL_API_KEY");
    if (!FIRECRAWL_API_KEY) {
      return reply({ success: false, error: "FIRECRAWL_API_KEY not configured" }, 200);
    }

    const { url } = await req.json().catch(() => ({ url: "" }));
    if (!url || typeof url !== "string" || !/^https?:\/\/.+yupoo\./i.test(url)) {
      return reply({ success: false, error: "Provide a valid yupoo URL" }, 200);
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: job, error: jobErr } = await supabase
      .from("import_jobs")
      .insert({ url, status: "queued", message: "Queued…" })
      .select()
      .single();
    if (jobErr || !job) {
      return reply({ success: false, error: jobErr?.message || "Could not create job" }, 200);
    }

    // Run the long task in the background; return immediately.
    // @ts-ignore EdgeRuntime is provided by Supabase Edge Runtime
    EdgeRuntime.waitUntil(runImport(job.id, url, FIRECRAWL_API_KEY));

    return reply({ success: true, jobId: job.id }, 202);
  } catch (e) {
    console.error("fatal", e);
    return reply({ success: false, error: e instanceof Error ? e.message : "Unknown error" }, 200);
  }
});
