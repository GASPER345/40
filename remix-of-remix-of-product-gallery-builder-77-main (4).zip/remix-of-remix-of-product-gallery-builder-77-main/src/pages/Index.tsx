import { useEffect, useState, useMemo, useRef } from "react";
import { Search, Loader2, CheckCircle2, AlertCircle, ShoppingCart, Trash2, Pencil, Plus, Minus, X, Copy, HelpCircle, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import legoLogo from "@/assets/logo.png";

const ADMIN_PASSWORD = "128482";
const ORDER_STATUSES = ["Ni še plačano", "Na poti", "Prejeto"] as const;

interface Category { id: string; name: string; slug: string; }
interface Product { id: string; name: string | null; image_url: string; category_id: string | null; }
interface CartItem { product: Product; qty: number; }
interface OrderRow { id: string; customer_name: string; phone: string; status: string; created_at: string; address?: string | null; city?: string | null; postal_code?: string | null; delivery_method?: string | null; pickup_date?: string | null; }
interface OrderItem { id: string; order_id: string; product_name: string | null; image_url: string | null; quantity: number; }

const REGIONS = ["Gorenjska", "Štajerska", "Primorska", "Notranjska", "Dolenjska", "Prekmurje", "Drugo"] as const;
type Region = typeof REGIONS[number];
const regionFromPostal = (pc?: string | null): Region => {
  const n = parseInt((pc || "").trim().slice(0, 4), 10);
  if (!n) return "Drugo";
  if (n >= 4000 && n <= 4299) return "Gorenjska";
  if (n >= 2000 && n <= 2999) return "Štajerska";
  if (n >= 3000 && n <= 3999) return "Štajerska";
  if (n >= 5000 && n <= 5999) return "Primorska";
  if (n >= 6000 && n <= 6999) return "Primorska";
  if (n >= 1380 && n <= 1386) return "Notranjska";
  if (n >= 8000 && n <= 8999) return "Dolenjska";
  if (n >= 9000 && n <= 9999) return "Prekmurje";
  return "Drugo";
};

// Local-date helpers (avoid UTC off-by-one from toISOString)
const toLocalISO = (d: Date) => {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
};
const parseLocalISO = (iso: string) => {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
};

const Index = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [activeCat, setActiveCat] = useState<string | null>(null);
  const [search, setSearch] = useState("");

  // Yupoo import
  const [dialogOpen, setDialogOpen] = useState(false);
  const [link, setLink] = useState("");
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState("");
  const [importedImages, setImportedImages] = useState(0);
  const [result, setResult] = useState<null | { ok: boolean; msg: string; cats?: number; imgs?: number }>(null);

  // Cart
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutName, setCheckoutName] = useState("");
  const [checkoutPhone, setCheckoutPhone] = useState("+386");
  const [checkoutAddress, setCheckoutAddress] = useState("");
  const [checkoutCity, setCheckoutCity] = useState("");
  const [checkoutPostal, setCheckoutPostal] = useState("");
  const [howToOpen, setHowToOpen] = useState(false);
  const [deliveryMethod, setDeliveryMethod] = useState<"dostava" | "prevzem">("dostava");
  const [pickupDate, setPickupDate] = useState<Date | undefined>(undefined);
  const [availablePickupDates, setAvailablePickupDates] = useState<string[]>([]);
  const [pickupSettingsId, setPickupSettingsId] = useState<string | null>(null);

  // Pickup admin (Ctrl+4)
  const [pickupAdminOpen, setPickupAdminOpen] = useState(false);
  const [adminSelectedDates, setAdminSelectedDates] = useState<Date[]>([]);

  // AI upload (Ctrl+1)
  const [uploadOpen, setUploadOpen] = useState(false);
  const [uploadBusy, setUploadBusy] = useState(false);
  const [uploadProgress, setUploadProgress] = useState({ done: 0, total: 0 });
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Editor (Ctrl+2)
  const [editorOpen, setEditorOpen] = useState(false);

  // Admin orders (Ctrl+3)
  const [ordersOpen, setOrdersOpen] = useState(false);
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [orderItems, setOrderItems] = useState<Record<string, OrderItem[]>>({});

  // Product preview & mobile category dropdown
  const [previewProduct, setPreviewProduct] = useState<Product | null>(null);
  const [mobileCatsOpen, setMobileCatsOpen] = useState(false);

  useEffect(() => {
    (async () => {
      const [{ data: cats }, { data: prods }, { data: ps }] = await Promise.all([
        supabase.from("categories").select("*").order("name"),
        supabase.from("products").select("*").order("created_at", { ascending: false }).limit(1000),
        supabase.from("pickup_settings" as any).select("*").limit(1).maybeSingle(),
      ]);
      if (cats) setCategories(cats);
      if (prods) setProducts(prods);
      if (ps) {
        setPickupSettingsId((ps as any).id);
        const d = (ps as any).available_dates;
        setAvailablePickupDates(Array.isArray(d) ? d : []);
      }
    })();
  }, []);

  // Realtime
  useEffect(() => {
    const ch = supabase
      .channel("gallery")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "categories" }, (p) => {
        setCategories((c) => [...c, p.new as Category].sort((a, b) => a.name.localeCompare(b.name)));
      })
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "products" }, (p) => {
        setProducts((c) => [p.new as Product, ...c]);
      })
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "products" }, (p) => {
        setProducts((c) => c.map((x) => (x.id === (p.new as Product).id ? (p.new as Product) : x)));
      })
      .on("postgres_changes", { event: "DELETE", schema: "public", table: "products" }, (p) => {
        setProducts((c) => c.filter((x) => x.id !== (p.old as Product).id));
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  // Keyboard shortcuts: Ctrl+1 (upload), Ctrl+2 (editor), Ctrl+3 (orders)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      const ctrl = e.ctrlKey || e.metaKey;
      if (!ctrl) return;
      if (!["1", "2", "3", "4", "l"].includes(k)) return;
      e.preventDefault();
      const pwd = window.prompt("Vnesi geslo:");
      if (pwd === null) return;
      if (pwd !== ADMIN_PASSWORD) {
        toast({ title: "Napačno geslo", description: "Dostop zavrnjen.", variant: "destructive" });
        return;
      }
      if (k === "1") setUploadOpen(true);
      else if (k === "2") setEditorOpen(true);
      else if (k === "3") { loadOrders(); setOrdersOpen(true); }
      else if (k === "4") {
        setAdminSelectedDates(availablePickupDates.map((s) => parseLocalISO(s)));
        setPickupAdminOpen(true);
      }
      else if (k === "l") setDialogOpen(true);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [availablePickupDates]);

  const filtered = useMemo(() => {
    const catOrder = new Map(categories.map((c, i) => [c.id, i]));
    return products
      .filter((p) => {
        if (activeCat && p.category_id !== activeCat) return false;
        if (search && !(p.name ?? "").toLowerCase().includes(search.toLowerCase())) return false;
        return true;
      })
      .sort((a, b) => {
        const ai = a.category_id ? catOrder.get(a.category_id) ?? Number.MAX_SAFE_INTEGER : Number.MAX_SAFE_INTEGER;
        const bi = b.category_id ? catOrder.get(b.category_id) ?? Number.MAX_SAFE_INTEGER : Number.MAX_SAFE_INTEGER;
        if (ai !== bi) return ai - bi;
        return (a.name ?? "").localeCompare(b.name ?? "", "sl", { sensitivity: "base" });
      });
  }, [products, categories, activeCat, search]);

  // ---------- Yupoo job ----------
  const jobChannelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const cleanupJobChannel = () => {
    if (jobChannelRef.current) { supabase.removeChannel(jobChannelRef.current); jobChannelRef.current = null; }
  };
  const handleJobRow = (job: any) => {
    const total = Math.max(1, job.products || 1);
    const pct = job.status === "completed" ? 100 : Math.min(95, 10 + Math.round((job.images / total) * 80));
    setProgress(pct);
    setImportedImages(job.images || 0);
    setStatusText(job.message || "");
    if (job.status === "completed") {
      setProgress(100);
      setResult({ ok: true, msg: job.message || "Končano", cats: job.categories, imgs: job.images });
      toast({ title: "Uvoz končan", description: `${job.categories} kategorij · ${job.images} slik.` });
      setLoading(false);
      cleanupJobChannel();
    } else if (job.status === "failed") {
      setResult({ ok: false, msg: job.message || "Uvoz ni uspel" });
      toast({ title: "Uvoz ni uspel", description: job.message || "Neznana napaka", variant: "destructive" });
      setLoading(false);
      cleanupJobChannel();
    }
  };
  const submitLink = async () => {
    const url = link.trim();
    if (!url) return;
    setLoading(true); setResult(null); setProgress(5); setImportedImages(0); setStatusText("Začenjam uvoz…");
    try {
      const { data, error } = await supabase.functions.invoke("scrape-yupoo", { body: { url } });
      if (error) throw new Error(error.message || "Napaka funkcije");
      if (!data?.success || !data?.jobId) throw new Error(data?.error || "Uvoz ni uspel");
      const jobId = data.jobId as string;
      cleanupJobChannel();
      const ch = supabase.channel(`import-job-${jobId}`)
        .on("postgres_changes", { event: "UPDATE", schema: "public", table: "import_jobs", filter: `id=eq.${jobId}` }, (p) => handleJobRow(p.new))
        .subscribe();
      jobChannelRef.current = ch;
      const poll = setInterval(async () => {
        if (!jobChannelRef.current) { clearInterval(poll); return; }
        const { data: row } = await supabase.from("import_jobs").select("*").eq("id", jobId).maybeSingle();
        if (row) handleJobRow(row);
        if (row && (row.status === "completed" || row.status === "failed")) clearInterval(poll);
      }, 3000);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "Uvoz ni uspel";
      setProgress(0); setStatusText(""); setResult({ ok: false, msg });
      toast({ title: "Uvoz ni uspel", description: msg, variant: "destructive" });
      setLoading(false);
    }
  };
  const closeDialog = () => {
    if (loading) return;
    cleanupJobChannel();
    setDialogOpen(false); setLink(""); setResult(null); setProgress(0); setStatusText("");
  };

  // ---------- Cart ----------
  const addToCart = (p: Product) => {
    setCart((c) => {
      const ex = c.find((i) => i.product.id === p.id);
      if (ex) return c.map((i) => i.product.id === p.id ? { ...i, qty: i.qty + 1 } : i);
      return [...c, { product: p, qty: 1 }];
    });
    toast({ title: "Dodano v košarico", description: p.name || "Set" });
  };
  const removeFromCart = (id: string) => setCart((c) => c.filter((i) => i.product.id !== id));
  const changeQty = (id: string, d: number) =>
    setCart((c) => c.map((i) => i.product.id === id ? { ...i, qty: Math.max(1, i.qty + d) } : i));

  const submitOrder = async () => {
    if (cart.length === 0) {
      toast({ title: "Košarica je prazna", variant: "destructive" }); return;
    }
    if (!checkoutName.trim()) { toast({ title: "Vnesi ime in priimek", variant: "destructive" }); return; }
    if (!/^\+386\d{6,}$/.test(checkoutPhone.trim())) {
      toast({ title: "Telefonska številka mora biti v obliki +386...", variant: "destructive" }); return;
    }
    if (deliveryMethod === "dostava") {
      if (!checkoutAddress.trim()) { toast({ title: "Vnesi naslov", variant: "destructive" }); return; }
      if (!checkoutCity.trim()) { toast({ title: "Vnesi kraj", variant: "destructive" }); return; }
      if (!/^\d{4}$/.test(checkoutPostal.trim())) { toast({ title: "Poštna številka mora imeti 4 številke", variant: "destructive" }); return; }
    } else {
      if (!pickupDate) { toast({ title: "Izberi termin prevzema", variant: "destructive" }); return; }
    }
    const { data: order, error } = await supabase.from("orders")
      .insert({
        customer_name: checkoutName.trim(),
        phone: checkoutPhone.trim(),
        delivery_method: deliveryMethod,
        address: deliveryMethod === "dostava" ? checkoutAddress.trim() : null,
        city: deliveryMethod === "dostava" ? checkoutCity.trim() : null,
        postal_code: deliveryMethod === "dostava" ? checkoutPostal.trim() : null,
        pickup_date: deliveryMethod === "prevzem" && pickupDate ? toLocalISO(pickupDate) : null,
      })
      .select().single();
    if (error || !order) { toast({ title: "Napaka pri oddaji", description: error?.message, variant: "destructive" }); return; }
    const items = cart.map((i) => ({
      order_id: order.id, product_id: i.product.id,
      product_name: i.product.name, image_url: i.product.image_url, quantity: i.qty,
    }));
    const { error: e2 } = await supabase.from("order_items").insert(items);
    if (e2) { toast({ title: "Napaka pri izdelkih", description: e2.message, variant: "destructive" }); return; }
    toast({ title: "Naročilo uspešno oddano!", description: "Kontaktirali vas bomo v najkrajšem možnem času na vašo telefonsko številko." });
    setCart([]); setCheckoutName(""); setCheckoutPhone("+386");
    setCheckoutAddress(""); setCheckoutCity(""); setCheckoutPostal("");
    setPickupDate(undefined); setDeliveryMethod("dostava");
    setCartOpen(false);
  };

  const savePickupDates = async () => {
    const arr = adminSelectedDates.map((d) => toLocalISO(d)).sort();
    if (pickupSettingsId) {
      const { error } = await supabase.from("pickup_settings" as any).update({ available_dates: arr, updated_at: new Date().toISOString() }).eq("id", pickupSettingsId);
      if (error) { toast({ title: "Napaka", description: error.message, variant: "destructive" }); return; }
    } else {
      const { data, error } = await supabase.from("pickup_settings" as any).insert({ available_dates: arr }).select().single();
      if (error || !data) { toast({ title: "Napaka", description: error?.message, variant: "destructive" }); return; }
      setPickupSettingsId((data as any).id);
    }
    setAvailablePickupDates(arr);
    toast({ title: "Termini shranjeni" });
    setPickupAdminOpen(false);
  };

  // ---------- AI Upload (Ctrl+1) ----------
  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const arr = Array.from(files).slice(0, 20);
    setUploadBusy(true);
    setUploadProgress({ done: 0, total: arr.length });
    const catNames = categories.map((c) => c.name);
    let done = 0;
    for (const file of arr) {
      try {
        // 1. upload to storage
        const ext = file.name.split(".").pop() || "jpg";
        const path = `ai/${crypto.randomUUID()}.${ext}`;
        const { error: upErr } = await supabase.storage.from("product-images").upload(path, file);
        if (upErr) throw upErr;
        const { data: pub } = supabase.storage.from("product-images").getPublicUrl(path);
        const imageUrl = pub.publicUrl;

        // 2. analyze with AI (base64 for reliability)
        const b64 = await new Promise<string>((res, rej) => {
          const r = new FileReader();
          r.onload = () => res((r.result as string).split(",")[1]);
          r.onerror = rej;
          r.readAsDataURL(file);
        });
        const { data: ai, error: aiErr } = await supabase.functions.invoke("analyze-product-image", {
          body: { imageBase64: b64, categories: catNames },
        });
        if (aiErr) throw aiErr;
        const name = ai?.name || "LEGO Set";
        const categoryName = ai?.category || "Drugo";

        // 3. find or create category
        let cat = categories.find((c) => c.name === categoryName);
        if (!cat) {
          const slug = categoryName.toLowerCase().replace(/\s+/g, "-");
          const { data: newCat } = await supabase.from("categories")
            .insert({ name: categoryName, slug }).select().single();
          if (newCat) { cat = newCat; setCategories((c) => [...c, newCat].sort((a, b) => a.name.localeCompare(b.name))); }
        }

        // 4. insert product
        await supabase.from("products").insert({
          name, image_url: imageUrl, category_id: cat?.id ?? null,
        });
      } catch (e) {
        console.error("upload error", e);
        toast({ title: "Napaka pri sliki", description: file.name, variant: "destructive" });
      }
      done++;
      setUploadProgress({ done, total: arr.length });
    }
    setUploadBusy(false);
    toast({ title: "Nalaganje končano", description: `${done} slik obdelanih.` });
  };

  // ---------- Editor (Ctrl+2) ----------
  const renameProduct = async (id: string, currentName: string) => {
    const v = window.prompt("Novo ime izdelka:", currentName);
    if (v === null) return;
    const { error } = await supabase.from("products").update({ name: v }).eq("id", id);
    if (error) toast({ title: "Napaka", description: error.message, variant: "destructive" });
    else setProducts((c) => c.map((p) => (p.id === id ? { ...p, name: v } : p)));
  };
  const moveProductCategory = async (id: string, newCategoryId: string) => {
    const { error } = await supabase.from("products").update({ category_id: newCategoryId }).eq("id", id);
    if (error) { toast({ title: "Napaka", description: error.message, variant: "destructive" }); return; }
    setProducts((c) => c.map((p) => (p.id === id ? { ...p, category_id: newCategoryId } : p)));
    toast({ title: "Premaknjeno", description: categories.find((c) => c.id === newCategoryId)?.name });
  };
  const deleteProduct = async (id: string) => {
    if (!window.confirm("Izbrisati ta izdelek?")) return;
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) toast({ title: "Napaka", description: error.message, variant: "destructive" });
    else setProducts((c) => c.filter((p) => p.id !== id));
  };

  // ---------- Orders (Ctrl+3) ----------
  const loadOrders = async () => {
    const { data: ord } = await supabase.from("orders").select("*").order("created_at", { ascending: false });
    const { data: it } = await supabase.from("order_items").select("*");
    setOrders(ord || []);
    const grouped: Record<string, OrderItem[]> = {};
    (it || []).forEach((i) => { (grouped[i.order_id] ||= []).push(i); });
    setOrderItems(grouped);
  };
  const updateOrderStatus = async (id: string, status: string) => {
    const { error } = await supabase.from("orders").update({ status }).eq("id", id);
    if (error) toast({ title: "Napaka", description: error.message, variant: "destructive" });
    else setOrders((o) => o.map((x) => x.id === id ? { ...x, status } : x));
  };

  const deleteOrder = async (id: string) => {
    if (!window.confirm("Izbrisati to naročilo?")) return;
    await supabase.from("order_items").delete().eq("order_id", id);
    const { error } = await supabase.from("orders").delete().eq("id", id);
    if (error) { toast({ title: "Napaka", description: error.message, variant: "destructive" }); return; }
    setOrders((o) => o.filter((x) => x.id !== id));
    setOrderItems((m) => { const c = { ...m }; delete c[id]; return c; });
    toast({ title: "Naročilo izbrisano" });
  };

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b-4 border-highlight bg-background">
        <div className="container flex flex-wrap items-center gap-2 py-3 sm:gap-4 sm:py-4">
          <img src={legoLogo} alt="LEGO" className="h-10 w-10 shrink-0 object-contain sm:h-14 sm:w-14" />
          <div className="order-3 flex w-full flex-1 justify-center sm:order-2 sm:w-auto">
            <div className="flex w-full max-w-sm items-center overflow-hidden rounded-md border-2 border-highlight bg-card">
              <Input
                placeholder="Išči sete"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="h-10 border-0 bg-transparent text-sm focus-visible:ring-0 focus-visible:ring-offset-0"
              />
              <Button size="sm" className="h-10 rounded-none bg-highlight px-3 text-white hover:bg-highlight/90">
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <div className="order-2 ml-auto flex items-center gap-2 shrink-0 sm:order-3 sm:ml-0">
            <Button
              onClick={() => setCartOpen(true)}
              variant="outline"
              size="sm"
              className="border-highlight bg-white text-foreground hover:bg-card sm:size-default"
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              <span>Košarica</span>
              {cartCount > 0 && <span className="ml-1">({cartCount})</span>}
            </Button>
            <Button
              onClick={() => setHowToOpen(true)}
              size="sm"
              className="bg-highlight text-white hover:bg-highlight/90 sm:size-default"
            >
              <HelpCircle className="h-4 w-4 mr-2" />
              <span>Kako naročiti</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="container py-6 sm:py-10">
        {/* Mobile category dropdown */}
        <div className="mb-4 lg:hidden">
          <button
            onClick={() => setMobileCatsOpen((v) => !v)}
            className="flex w-full items-center justify-between rounded-md border-2 border-highlight bg-card px-4 py-3 text-sm font-medium"
          >
            <span>{activeCat ? categories.find((c) => c.id === activeCat)?.name : "Vse kategorije"}</span>
            <ChevronDown className={`h-4 w-4 transition-transform ${mobileCatsOpen ? "rotate-180" : ""}`} />
          </button>
          {mobileCatsOpen && (
            <div className="mt-1 max-h-72 overflow-y-auto rounded-md border bg-background p-1 shadow-lg">
              <button
                onClick={() => { setActiveCat(null); setMobileCatsOpen(false); }}
                className={`w-full rounded px-3 py-2 text-left text-sm ${activeCat === null ? "bg-highlight text-white" : "hover:bg-card"}`}
              >Vse kategorije</button>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => { setActiveCat(cat.id); setMobileCatsOpen(false); }}
                  className={`w-full rounded px-3 py-2 text-left text-sm ${activeCat === cat.id ? "bg-highlight text-white" : "hover:bg-card"}`}
                >{cat.name}</button>
              ))}
            </div>
          )}
        </div>

        <div className="grid gap-8 lg:grid-cols-[220px_1fr]">
          <aside className="hidden space-y-1 lg:block">
            <button
              onClick={() => setActiveCat(null)}
              className={`w-full rounded-md px-4 py-3 text-left text-sm transition-colors ${
                activeCat === null ? "bg-highlight font-medium text-white shadow-sm" : "text-foreground/80 hover:bg-card"
              }`}
            >
              Vse kategorije
            </button>
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCat(cat.id)}
                className={`w-full rounded-md px-4 py-3 text-left text-sm transition-colors ${
                  activeCat === cat.id ? "bg-highlight font-medium text-white shadow-sm" : "text-foreground/80 hover:bg-card"
                }`}
              >
                {cat.name}
              </button>
            ))}
          </aside>

          <section>
            <div className="mb-2 flex items-baseline justify-between border-b-2 border-highlight pb-3">
              <h3 className="text-lg font-bold">
                {activeCat ? categories.find((c) => c.id === activeCat)?.name : "Vse kategorije"}
              </h3>
              <span className="text-sm text-muted-foreground">{filtered.length} setov</span>
            </div>
            <p className="mb-6 text-sm text-muted-foreground">
              skupaj {products.length} setov v {categories.length} kategorijah
            </p>

            {filtered.length === 0 ? (
              <div className="grid grid-cols-2 gap-3 sm:gap-5 sm:grid-cols-3 md:grid-cols-4">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} className="space-y-2">
                    <div className="aspect-square rounded-md bg-placeholder" />
                    <div className="h-3 w-3/4 rounded bg-placeholder" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3 sm:gap-5 sm:grid-cols-3 md:grid-cols-4">
                {filtered.map((p) => (
                  <article key={p.id} className="group space-y-2">
                    <button
                      onClick={() => setPreviewProduct(p)}
                      className="relative block aspect-square w-full overflow-hidden rounded-md bg-placeholder"
                    >
                      <img src={p.image_url} alt={p.name ?? "set"} loading="lazy"
                        className="h-full w-full object-cover transition-transform group-hover:scale-105" />
                    </button>
                    <h4 className="truncate text-sm font-medium" title={p.name ?? ""}>{p.name || "Brez imena"}</h4>
                  </article>
                ))}
              </div>
            )}
          </section>
        </div>
      </main>

      {/* Product preview dialog */}
      <Dialog open={!!previewProduct} onOpenChange={(o) => !o && setPreviewProduct(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{previewProduct?.name || "Set"}</DialogTitle>
          </DialogHeader>
          {previewProduct && (
            <div className="space-y-4">
              <img src={previewProduct.image_url} alt={previewProduct.name ?? ""} className="max-h-[70vh] w-full rounded-md object-contain" />
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setPreviewProduct(null)}>Zapri</Button>
            <Button
              onClick={() => { if (previewProduct) { addToCart(previewProduct); setPreviewProduct(null); } }}
              className="bg-highlight text-white hover:bg-highlight/90"
            >
              <ShoppingCart className="mr-2 h-4 w-4" />Dodaj v košarico
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Yupoo dialog */}
      <Dialog open={dialogOpen} onOpenChange={(o) => (o ? setDialogOpen(true) : closeDialog())}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Uvoz iz Yupoo</DialogTitle>
            <DialogDescription>Prilepi yupoo URL.</DialogDescription>
          </DialogHeader>
          <Input autoFocus placeholder="https://example.x.yupoo.com/albums/123456"
            value={link} onChange={(e) => setLink(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !loading) submitLink(); }} disabled={loading} />
          {(loading || progress > 0 || result) && (
            <div className="space-y-2">
              <Progress value={progress} />
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span className="flex items-center gap-2">
                  {loading && <Loader2 className="h-3 w-3 animate-spin" />}
                  {result?.ok && <CheckCircle2 className="h-3 w-3 text-green-600" />}
                  {result && !result.ok && <AlertCircle className="h-3 w-3 text-destructive" />}
                  {statusText || result?.msg || ""}
                </span>
                {loading && importedImages > 0 && <span>{importedImages} slik</span>}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={closeDialog} disabled={loading}>{result ? "Zapri" : "Prekliči"}</Button>
            <Button onClick={submitLink} disabled={loading || !link.trim()} className="bg-highlight text-white hover:bg-highlight/90">
              {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Skeniram…</> : "Uvozi"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Cart dialog */}
      <Dialog open={cartOpen} onOpenChange={setCartOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Košarica</DialogTitle>
          </DialogHeader>
          {cart.length === 0 ? (
            <p className="text-sm text-muted-foreground">Košarica je prazna.</p>
          ) : (
            <div className="space-y-3 max-h-[40vh] overflow-y-auto">
              {cart.map((i) => (
                <div key={i.product.id} className="flex items-center gap-3 border rounded p-2">
                  <img src={i.product.image_url} className="h-14 w-14 rounded object-cover" alt="" />
                  <div className="flex-1 truncate text-sm">{i.product.name || "Set"}</div>
                  <Button size="icon" variant="outline" onClick={() => changeQty(i.product.id, -1)}><Minus className="h-3 w-3" /></Button>
                  <span className="w-6 text-center text-sm">{i.qty}</span>
                  <Button size="icon" variant="outline" onClick={() => changeQty(i.product.id, 1)}><Plus className="h-3 w-3" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => removeFromCart(i.product.id)}><X className="h-4 w-4" /></Button>
                </div>
              ))}
            </div>
          )}
          <div className="space-y-2 pt-2 border-t">
            <Input placeholder="Ime in priimek" value={checkoutName} onChange={(e) => setCheckoutName(e.target.value)} />
            <Input placeholder="+386..." value={checkoutPhone} onChange={(e) => setCheckoutPhone(e.target.value)} />
            <div className="space-y-2 rounded-md border p-3">
              <p className="text-sm font-medium">Način prevzema</p>
              <RadioGroup value={deliveryMethod} onValueChange={(v) => setDeliveryMethod(v as "dostava" | "prevzem")} className="flex gap-4">
                <div className="flex items-center gap-2">
                  <RadioGroupItem value="dostava" id="dm-d" />
                  <Label htmlFor="dm-d">Dostava na dom</Label>
                </div>
                <div className="flex items-center gap-2">
                  <RadioGroupItem value="prevzem" id="dm-p" />
                  <Label htmlFor="dm-p">Osebni prevzem</Label>
                </div>
              </RadioGroup>
            </div>
            {deliveryMethod === "dostava" ? (
              <>
                <Input placeholder="Naslov (ulica in hišna številka)" value={checkoutAddress} onChange={(e) => setCheckoutAddress(e.target.value)} />
                <div className="grid grid-cols-[1fr_120px] gap-2">
                  <Input placeholder="Kraj" value={checkoutCity} onChange={(e) => setCheckoutCity(e.target.value)} />
                  <Input placeholder="Poštna št." value={checkoutPostal} onChange={(e) => setCheckoutPostal(e.target.value)} maxLength={4} />
                </div>
              </>
            ) : (
              <div className="rounded-md border p-3">
                <p className="mb-2 text-sm font-medium">Izberi termin osebnega prevzema</p>
                {(() => {
                  const today = new Date(); today.setHours(0, 0, 0, 0);
                  const future = availablePickupDates
                    .filter((iso) => parseLocalISO(iso) >= today)
                    .sort();
                  if (future.length === 0) {
                    return <p className="text-xs text-muted-foreground">Trenutno ni razpisanih terminov. Prosim izberi dostavo ali poskusi kasneje.</p>;
                  }
                  const selIso = pickupDate ? toLocalISO(pickupDate) : null;
                  return (
                    <>
                      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                        {future.map((iso) => {
                          const d = parseLocalISO(iso);
                          const isSel = selIso === iso;
                          return (
                            <button
                              key={iso}
                              type="button"
                              onClick={() => setPickupDate(d)}
                              className={`rounded-md border-2 px-3 py-2 text-sm font-medium transition-colors text-center ${
                                isSel
                                  ? "border-highlight bg-highlight text-white"
                                  : "border-highlight bg-card text-foreground hover:bg-highlight/10"
                              }`}
                            >
                              {d.toLocaleDateString("sl-SI", { weekday: "short", day: "numeric", month: "numeric", year: "numeric" })}
                            </button>
                          );
                        })}
                      </div>
                      {pickupDate ? (
                        <p className="mt-3 text-sm">Izbran termin: <strong>{pickupDate.toLocaleDateString("sl-SI", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</strong>. Za potrditev pritisni gumb spodaj.</p>
                      ) : (
                        <p className="mt-3 text-xs text-muted-foreground">Izberi enega od razpoložljivih terminov.</p>
                      )}
                    </>
                  );
                })()}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCartOpen(false)}>Zapri</Button>
            <Button
              onClick={submitOrder}
              disabled={cart.length === 0 || (deliveryMethod === "prevzem" && !pickupDate)}
              className="bg-highlight text-white hover:bg-highlight/90"
            >
              {deliveryMethod === "prevzem" ? "Potrdi termin in oddaj naročilo" : "Oddaj naročilo"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* AI Upload (Ctrl+1) */}
      <Dialog open={uploadOpen} onOpenChange={(o) => !uploadBusy && setUploadOpen(o)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Naloži slike (AI obdelava)</DialogTitle>
            <DialogDescription>Izberi do 20 slik. AI bo samodejno določil ime in kategorijo.</DialogDescription>
          </DialogHeader>
          <input ref={fileInputRef} type="file" accept="image/*" multiple
            onChange={(e) => handleFiles(e.target.files)} className="hidden" />
          <Button onClick={() => fileInputRef.current?.click()} disabled={uploadBusy}
            className="bg-highlight text-white hover:bg-highlight/90">
            Izberi slike
          </Button>
          {uploadBusy && (
            <div className="space-y-2">
              <Progress value={uploadProgress.total ? (uploadProgress.done / uploadProgress.total) * 100 : 0} />
              <p className="text-xs text-muted-foreground">{uploadProgress.done} / {uploadProgress.total} obdelanih</p>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setUploadOpen(false)} disabled={uploadBusy}>Zapri</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Editor (Ctrl+2) */}
      <Dialog open={editorOpen} onOpenChange={setEditorOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Urejevalnik izdelkov</DialogTitle>
            <DialogDescription>Preimenuj ali izbriši izdelke.</DialogDescription>
          </DialogHeader>
          <div className="max-h-[60vh] overflow-y-auto space-y-2">
            {products.map((p) => (
              <div key={p.id} className="flex flex-wrap items-center gap-2 border rounded p-2 sm:flex-nowrap sm:gap-3">
                <img src={p.image_url} className="h-12 w-12 rounded object-cover" alt="" />
                <div className="min-w-0 flex-1 truncate text-sm">{p.name || "Brez imena"}</div>
                <Select value={p.category_id ?? ""} onValueChange={(v) => moveProductCategory(p.id, v)}>
                  <SelectTrigger className="h-9 w-[160px]"><SelectValue placeholder="Kategorija" /></SelectTrigger>
                  <SelectContent>
                    {categories.map((c) => (<SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>))}
                  </SelectContent>
                </Select>
                <Button size="sm" variant="outline" onClick={() => renameProduct(p.id, p.name || "")}>
                  <Pencil className="mr-1 h-3 w-3" />Preimenuj
                </Button>
                <Button size="sm" variant="destructive" onClick={() => deleteProduct(p.id)}>
                  <Trash2 className="mr-1 h-3 w-3" />Izbriši
                </Button>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditorOpen(false)}>Zapri</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Orders admin (Ctrl+3) */}
      <Dialog open={ordersOpen} onOpenChange={setOrdersOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Naročila</DialogTitle>
          </DialogHeader>
          {orders.length > 0 && (
            <div className="flex flex-wrap gap-2 border-b pb-2">
              <Button size="sm" variant="outline" onClick={() => {
                const txt = orders.map((o) => o.customer_name).join("\n");
                navigator.clipboard.writeText(txt);
                toast({ title: "Kopirana vsa imena", description: `${orders.length} imen` });
              }}>
                <Copy className="mr-1 h-3 w-3" />Kopiraj vsa imena
              </Button>
              <Button size="sm" variant="outline" onClick={() => {
                const txt = orders.map((o) => o.phone).join("\n");
                navigator.clipboard.writeText(txt);
                toast({ title: "Kopirane vse številke", description: `${orders.length} številk` });
              }}>
                <Copy className="mr-1 h-3 w-3" />Kopiraj vse številke
              </Button>
              <Button size="sm" variant="outline" onClick={() => {
                const txt = orders.map((o) => `${o.customer_name}\t${o.phone}`).join("\n");
                navigator.clipboard.writeText(txt);
                toast({ title: "Kopirano", description: `${orders.length} vnosov` });
              }}>
                <Copy className="mr-1 h-3 w-3" />Kopiraj imena + številke
              </Button>
            </div>
          )}
          <div className="max-h-[65vh] overflow-y-auto space-y-6">
            {orders.length === 0 && <p className="text-sm text-muted-foreground">Ni naročil.</p>}
            {REGIONS.map((region) => {
              const regionOrders = orders.filter((o) => regionFromPostal(o.postal_code) === region);
              if (regionOrders.length === 0) return null;
              return (
                <div key={region} className="space-y-2">
                  <h3 className="border-b-2 border-highlight pb-1 text-base font-bold">
                    {region} <span className="text-xs font-normal text-muted-foreground">({regionOrders.length})</span>
                  </h3>
                  {regionOrders.map((o) => (
                    <div key={o.id} className="border rounded p-3 space-y-2">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <p className="font-semibold">{o.customer_name}</p>
                            <button
                              onClick={() => {
                                navigator.clipboard.writeText(o.customer_name);
                                toast({ title: "Kopirano", description: o.customer_name });
                              }}
                              className="inline-flex h-5 w-5 items-center justify-center rounded hover:bg-card"
                              aria-label="Kopiraj ime"
                            >
                              <Copy className="h-3 w-3" />
                            </button>
                          </div>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <span>{o.phone}</span>
                            <button
                              onClick={() => {
                                navigator.clipboard.writeText(o.phone);
                                toast({ title: "Kopirano", description: o.phone });
                              }}
                              className="inline-flex h-5 w-5 items-center justify-center rounded hover:bg-card"
                              aria-label="Kopiraj telefonsko številko"
                            >
                              <Copy className="h-3 w-3" />
                            </button>
                          </div>
                          <p className="text-xs font-medium text-highlight">
                            {o.delivery_method === "prevzem" ? `Osebni prevzem${o.pickup_date ? ` · ${new Date(o.pickup_date).toLocaleDateString("sl-SI")}` : ""}` : "Dostava na dom"}
                          </p>
                          {o.delivery_method !== "prevzem" && (o.address || o.city || o.postal_code) && (
                            <p className="text-xs text-muted-foreground">
                              {o.address}{o.address ? ", " : ""}{o.postal_code} {o.city}
                            </p>
                          )}
                          <p className="text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString("sl-SI")}</p>
                        </div>
                        <Select value={o.status} onValueChange={(v) => updateOrderStatus(o.id, v)}>
                          <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {ORDER_STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                          </SelectContent>
                        </Select>
                        <Button size="icon" variant="destructive" onClick={() => deleteOrder(o.id)} aria-label="Izbriši naročilo">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {(orderItems[o.id] || []).map((it) => (
                          <div key={it.id} className="flex items-center gap-2 border rounded p-1 text-xs">
                            {it.image_url && <img src={it.image_url} className="h-8 w-8 rounded object-cover" alt="" />}
                            <span>{it.product_name} × {it.quantity}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOrdersOpen(false)}>Zapri</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Kako naročiti */}
      <Dialog open={howToOpen} onOpenChange={setHowToOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Kako naročiti</DialogTitle>
            <DialogDescription>Naročilo v nekaj preprostih korakih.</DialogDescription>
          </DialogHeader>
          <ol className="list-decimal space-y-2 pl-5 text-sm">
            <li>Brskaj po kategorijah ali uporabi iskalnik za želeni LEGO set.</li>
            <li>Klikni na sliko želenega seta. Odprla se ti bo stran, kjer izdelek dodaš v košarico.</li>
            <li>Odpri košarico zgoraj desno in preveri izbrane sete.</li>
            <li>Vnesi svoje ime, telefonsko številko (+386), naslov, kraj in poštno številko.</li>
            <li>Oddaj naročilo. Kontaktirali te bomo v najkrajšem možnem času na telefonsko številko za potrditev in dogovor o plačilu ter dostavi.</li>
          </ol>
          <DialogFooter>
            <Button onClick={() => setHowToOpen(false)} className="bg-highlight text-white hover:bg-highlight/90">Razumem</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Pickup admin (Ctrl+4) */}
      <Dialog open={pickupAdminOpen} onOpenChange={setPickupAdminOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Termini osebnega prevzema</DialogTitle>
            <DialogDescription>Klikni dneve, ko je možen osebni prevzem. Stranke bodo lahko izbirale samo med temi termini.</DialogDescription>
          </DialogHeader>
          <Calendar
            mode="multiple"
            selected={adminSelectedDates}
            onSelect={(d) => setAdminSelectedDates(d || [])}
            disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
            className="pointer-events-auto"
          />
          <p className="text-xs text-muted-foreground">Izbranih: {adminSelectedDates.length}</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPickupAdminOpen(false)}>Prekliči</Button>
            <Button onClick={savePickupDates} className="bg-highlight text-white hover:bg-highlight/90">Shrani</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Index;
